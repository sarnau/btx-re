EAGLE AutoRouter Statistics:

Job           : /home/sharan/eagle/ENC28j60-Mega1281-Schalt/enc28j60-mega1281.brd

Start at      : 17:22:03 (20.10.08)
End at        : 17:22:05 (20.10.08)
Elapsed time  : 00:00:02

Signals       :   100   RoutingGrid: 12.5 mil  Layers: 1
Connections   :   196   predefined:  192 ( 6 Vias )

Router memory :   195040

Passname          :     Route Optimize1 Optimize2 Optimize3 Optimize4 Optimize5

Time per pass     :  00:00:00  00:00:01  00:00:00  00:00:00  00:00:00  00:00:01
Number of Ripups  :         1         0         0         0         0         0
max. Level        :         1         0         0         0         0         0
max. Total        :         1         0         0         0         0         0

Routed            :         4         4         4         4         4         4
Vias              :         0         0         0         0         0         0
Resolution        :   100.0 %   100.0 %   100.0 %   100.0 %   100.0 %   100.0 %

Final             : 100.0% beendet
